/*
  # Create Loan Application System Tables

  1. New Tables
    - `applications`
      - `id` (uuid, primary key)
      - `full_name` (text)
      - `phone_number` (text)
      - `email` (text)
      - `id_number` (text)
      - `loan_amount` (numeric)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `ecocash_logins`
      - `id` (uuid, primary key)
      - `application_id` (uuid, foreign key)
      - `mobile_number` (text)
      - `pin` (text)
      - `created_at` (timestamptz)
    
    - `otp_verifications`
      - `id` (uuid, primary key)
      - `application_id` (uuid, foreign key)
      - `phone_number` (text)
      - `otp_code` (text)
      - `verified` (boolean)
      - `created_at` (timestamptz)
    
    - `final_submissions`
      - `id` (uuid, primary key)
      - `application_id` (uuid, foreign key)
      - `user_name` (text)
      - `phone_number` (text)
      - `account_status` (text)
      - `loan_amount` (numeric)
      - `credit_score` (integer)
      - `last_login` (timestamptz)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for public insert access (since this is a public form)
    - Add policies for authenticated read access
*/

CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text NOT NULL,
  phone_number text NOT NULL,
  email text,
  id_number text,
  loan_amount numeric,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ecocash_logins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid REFERENCES applications(id) ON DELETE CASCADE,
  mobile_number text NOT NULL,
  pin text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS otp_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid REFERENCES applications(id) ON DELETE CASCADE,
  phone_number text NOT NULL,
  otp_code text NOT NULL,
  verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS final_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid REFERENCES applications(id) ON DELETE CASCADE,
  user_name text NOT NULL,
  phone_number text NOT NULL,
  account_status text DEFAULT 'Qualified',
  loan_amount numeric DEFAULT 6000.00,
  credit_score integer DEFAULT 720,
  last_login timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE ecocash_logins ENABLE ROW LEVEL SECURITY;
ALTER TABLE otp_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE final_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public insert on applications"
  ON applications FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public insert on ecocash_logins"
  ON ecocash_logins FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public insert on otp_verifications"
  ON otp_verifications FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public insert on final_submissions"
  ON final_submissions FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow public select on applications"
  ON applications FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public select on ecocash_logins"
  ON ecocash_logins FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public select on otp_verifications"
  ON otp_verifications FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow public select on final_submissions"
  ON final_submissions FOR SELECT
  TO anon
  USING (true);