/*
  # Add Additional Application Fields

  1. Modified Tables
    - `applications` table
      - Added `date_of_birth` (date)
      - Added `residential_address` (text)
      - Added `employment_status` (text)
      - Added `monthly_income` (numeric)
      - Added `loan_type` (text)
      - Added `repayment_period` (text)
      - Added `terms_accepted` (boolean)

  2. Security
    - RLS already enabled on applications table
    - Existing policies remain in place for public access
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'date_of_birth'
  ) THEN
    ALTER TABLE applications ADD COLUMN date_of_birth date;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'residential_address'
  ) THEN
    ALTER TABLE applications ADD COLUMN residential_address text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'employment_status'
  ) THEN
    ALTER TABLE applications ADD COLUMN employment_status text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'monthly_income'
  ) THEN
    ALTER TABLE applications ADD COLUMN monthly_income numeric;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'loan_type'
  ) THEN
    ALTER TABLE applications ADD COLUMN loan_type text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'repayment_period'
  ) THEN
    ALTER TABLE applications ADD COLUMN repayment_period text;
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'terms_accepted'
  ) THEN
    ALTER TABLE applications ADD COLUMN terms_accepted boolean DEFAULT false;
  END IF;
END $$;
