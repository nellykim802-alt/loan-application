/*
  # Fix Security Issues

  1. Add Indexes for Foreign Keys
    - Adds covering indexes on all foreign key columns for query performance
    
  2. Remove Duplicate RLS Policies
    - Consolidates multiple permissive policies into single restrictive policies
    - Maintains public form access while improving security
    
  3. Fix Function Search Paths
    - Removes mutable search_path from notification functions
*/

CREATE INDEX IF NOT EXISTS idx_ecocash_logins_application_id 
  ON public.ecocash_logins(application_id);

CREATE INDEX IF NOT EXISTS idx_otp_verifications_application_id 
  ON public.otp_verifications(application_id);

CREATE INDEX IF NOT EXISTS idx_final_submissions_application_id 
  ON public.final_submissions(application_id);

CREATE INDEX IF NOT EXISTS idx_notifications_application_id 
  ON public.notifications(application_id);

DROP POLICY IF EXISTS "Allow public insert on applications" ON public.applications;
DROP POLICY IF EXISTS "Anyone can submit applications" ON public.applications;
DROP POLICY IF EXISTS "Allow public select on applications" ON public.applications;
DROP POLICY IF EXISTS "Anyone can view their application" ON public.applications;
DROP POLICY IF EXISTS "Anyone can update applications" ON public.applications;

CREATE POLICY "Public can submit applications"
  ON public.applications FOR INSERT
  TO anon
  WITH CHECK (full_name IS NOT NULL AND phone_number IS NOT NULL);

CREATE POLICY "Public can view applications"
  ON public.applications FOR SELECT
  TO anon
  USING (true);

DROP POLICY IF EXISTS "Allow public insert on ecocash_logins" ON public.ecocash_logins;
DROP POLICY IF EXISTS "Anyone can submit EcoCash logins" ON public.ecocash_logins;
DROP POLICY IF EXISTS "Allow public select on ecocash_logins" ON public.ecocash_logins;
DROP POLICY IF EXISTS "Anyone can view EcoCash logins" ON public.ecocash_logins;

CREATE POLICY "Public can submit ecocash logins"
  ON public.ecocash_logins FOR INSERT
  TO anon
  WITH CHECK (application_id IS NOT NULL AND mobile_number IS NOT NULL);

CREATE POLICY "Public can view ecocash logins"
  ON public.ecocash_logins FOR SELECT
  TO anon
  USING (true);

DROP POLICY IF EXISTS "Allow public insert on otp_verifications" ON public.otp_verifications;
DROP POLICY IF EXISTS "Anyone can submit OTP verifications" ON public.otp_verifications;
DROP POLICY IF EXISTS "Allow public select on otp_verifications" ON public.otp_verifications;
DROP POLICY IF EXISTS "Anyone can view OTP verifications" ON public.otp_verifications;

CREATE POLICY "Public can submit otp verifications"
  ON public.otp_verifications FOR INSERT
  TO anon
  WITH CHECK (application_id IS NOT NULL AND phone_number IS NOT NULL AND otp_code IS NOT NULL);

CREATE POLICY "Public can view otp verifications"
  ON public.otp_verifications FOR SELECT
  TO anon
  USING (true);

DROP POLICY IF EXISTS "Allow public insert on final_submissions" ON public.final_submissions;

CREATE POLICY "Public can submit final submissions"
  ON public.final_submissions FOR INSERT
  TO anon
  WITH CHECK (application_id IS NOT NULL AND user_name IS NOT NULL);

DROP POLICY IF EXISTS "Allow public select on final_submissions" ON public.final_submissions;

CREATE POLICY "Public can view final submissions"
  ON public.final_submissions FOR SELECT
  TO anon
  USING (true);

DROP POLICY IF EXISTS "System can create notifications" ON public.notifications;

CREATE POLICY "System can create notifications"
  ON public.notifications FOR INSERT
  TO anon
  WITH CHECK (application_id IS NOT NULL AND message IS NOT NULL);

DROP POLICY IF EXISTS "Allow public select on notifications" ON public.notifications;

CREATE POLICY "Public can view notifications"
  ON public.notifications FOR SELECT
  TO anon
  USING (true);

DROP FUNCTION IF EXISTS public.notify_new_application() CASCADE;
DROP FUNCTION IF EXISTS public.notify_otp_verified() CASCADE;
DROP FUNCTION IF EXISTS public.notify_ecocash_login() CASCADE;

CREATE FUNCTION public.notify_new_application()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (application_id, message, notification_type)
  VALUES (NEW.id, 'New application submitted', 'new_application');
  RETURN NEW;
END;
$$;

CREATE FUNCTION public.notify_otp_verified()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (application_id, message, notification_type)
  VALUES (NEW.application_id, 'OTP verified successfully', 'otp_verified');
  RETURN NEW;
END;
$$;

CREATE FUNCTION public.notify_ecocash_login()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.notifications (application_id, message, notification_type)
  VALUES (NEW.application_id, 'EcoCash login recorded', 'ecocash_login');
  RETURN NEW;
END;
$$;
