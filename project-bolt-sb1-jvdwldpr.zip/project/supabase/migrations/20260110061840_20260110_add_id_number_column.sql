/*
  # Add ID Number Column to Applications

  Adds a new column to collect ID number data from application submissions.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'applications' AND column_name = 'id_number'
  ) THEN
    ALTER TABLE public.applications ADD COLUMN id_number text;
  END IF;
END $$;
